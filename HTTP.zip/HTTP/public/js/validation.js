$("#registerBtn").click(function(e){
	var error = false;

	//e.preventDefault();//remember to delete this to prevent the form from refreshing


	//name validation done
	var name = document.getElementById('name').value;
	alert(name);
	if(name == ''){
		document.getElementById('errName').innerHTML = '*Must be filled';
		error = true;
	}else{
		document.getElementById('errName').innerHTML = '';
	}

	//email validation done
	var email = document.getElementById('email').value;
	// var emailValidation = Email.includes('@@' || '@@com');
	// if(email == ''){
	// 	document.getElementById('errEmail').innerHTML = '*Must be filled';
	// }

	// else if(emailValidation == true ){
	// 	document.getElementById('errEmail').innerHTML = '*Your email is invalid';
	// }
	
	//var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	//if(email.value.match(mailformat))
	//{
	//	document.getElementById('errEmail').innerHTML = '';
	//}
	//else
	//{
	//	document.getElementById('errEmail').innerHTML = '*Your email is invalid';
	//	error = true;
	//}

	//nim validation done
	var nim = document.getElementById('nim').value;
	var nimLength = nim.length;
	if(nimLength != 10){
		document.getElementById('errNim').innerHTML = '*Must be exactly 10';
		error = true;
	}
	else{
		document.getElementById('errNim').innerHTML = ' ';
	}

	//phone validation  done
	var phone = document.getElementById('phone').value;
	var phoneLength = phone.length;
	if(phoneLength < 10 || phoneLength > 13){
		document.getElementById('errPhone').innerHTML = '*Length Must be between 10-13';
		error = true;
	}
	else{
		document.getElementById('errPhone').innerHTML = ' ';
	}

	//line validation done
	var line = document.getElementById('line').value;
	if(line == ''){
		document.getElementById('errLine').innerHTML = '*Must be filled';
		error = true;
	}
	else{
		document.getElementById('errLine').innerHTML = ' ';
	}

	//jurusan validation done
	var jurusan = document.getElementById('jurusan').value;
	if(jurusan == ''){
		document.getElementById('errJurusan').innerHTML = '*Must be filled';
		error = true;
	}
	else{
		document.getElementById('errJurusan').innerHTML = ' ';
	}

	//batch validation done
	var batch = document.getElementById('batch').value;
	if(batch < 1 || batch > 5){
		document.getElementById('errBatch').innerHTML = '*Must between 1-5';
		error = true;
	}
	else{
		document.getElementById('errBatch').innerHTML = '';
	}

	//region validation done
	var region = document.getElementById('region').value;
	var regionValidation = Address.includes('AS') || Address.includes('PPTI') || Address.includes('KG') ;
	if (regionValidation == 0)
	{
		document.getElementById('errRegion').innerHTML = '*AS/KG/PPTI';
		error = true;
	} 
	else {
		document.getElementById('errRegion').innerHTML = ' ';
	}
	//transport validation done
	var transport = document.getElementById('transport').value;
	if(transport == ''){
		document.getElementById('errTransport').innerHTML = '*Must be filled';
		error = true;
	}
	else{
		document.getElementById('errTransport').innerHTML = ' ';
	}
	
	//vege or non vege validation done
	if(document.getElementById('rbVege').checked == false && document.getElementById('rbNonVege').checked == false)
	{
		document.getElementById('errVege').innerHTML = '*Please select one';
		error = true;
	}else{
		document.getElementById('errVege').innerHTML = '';
	}

	//baju validation done
	var objectDDL = document.getElementById('ddlbaju');
	var bajuValue = ObjectDDL.options[ObjectDDL.selectedIndex].value;
	if(bajuValue == '-1'){
		document.getElementById('errBaju').innerHTML = '*Must be chosen';
		error = true;
	}
	else{
		document.getElementById('errBaju').innerHTML = ' ';
	}

	// pemabayaran validation done
	var objectDDL2 = document.getElementById('ddlpembayaran');
	var pembayaranValue = ObjectDDL2.options[ObjectDDL2.selectedIndex].value;

	if(pembayaranValue == '-1'){
		document.getElementById('errPembayaran').innerHTML = '*Must be chosen';
		error = true;
	}
	else{
		document.getElementById('errPembayaran').innerHTML = ' ';
	}

	//tiket validation done
	var ticket = document.getElementById('ticket').value;
	if(ticket == ''){
		document.getElementById('errTicket').innerHTML = '*Must be filled';
		error = true;
	}
	else{
		document.getElementById('errTicket').innerHTML = ' ';
	}

	if(error == true){
        e.preventDefault();
    }
});