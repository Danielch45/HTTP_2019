<!DOCTYPE html>
<html>
<head>
	<title>REGISTER</title>
</head>
<body>
	<h3>Side Note: Selagi nunggu desain, gunakan form ini untuk validasi</h3>

	<form method="post" action="/register"> <!-- semua tidak boleh empty atau tidak dipilih -->
		<?php echo e(csrf_field()); ?>

		<input type="text" name="name" placeholder="name"><br>
		<input type="text" name="email" placeholder="email"><br> <!-- validasi email biasa -->
		<input type="text" name="nim" placeholder="nim"><br> <!-- panjang kata 10, number only -->
		<input type="text" name="phone" placeholder="phone"><br> <!-- panjang kata 10-13, number only -->
		<input type="text" name="line" placeholder="line"><br>
		<input type="text" name="jurusan" placeholder="jurusan"><br> 
		<input type="text" name="batch" placeholder="batch"><br> <!-- 1 sampe 5 -->
		<input type="text" name="region" placeholder="region"> <br> <!-- Alsut , Kemanggisan atau PPTI -->
		<input type="text" name="transport" placeholder="transport"><br>
		<input type="radio" name="vege" value="vege">Vege
		<input type="radio" name="vege" value="non-vege">Non-Vege <br>
		<select name="baju" style="width: 170px;"> <!-- pilih apaaja yang penting valuenya bukan ----- -->
			<option value="-----">-----</option> 
			<option value="Small">S</option>
			<option value="Medium">M</option>
			<option value="Large">L</option>
		</select> <br>
		<button type="submit" name="submit">Submit</button>
	</form>

</body>
</html>