<!DOCTYPE html>
<html>
<head>
	<title>SUCCESS</title>
</head>
<body>
<h1>SUCCESS REGISTERING</h1>
</body>
</html>