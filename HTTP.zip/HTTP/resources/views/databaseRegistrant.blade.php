<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="{{URL::asset('css/database.css')}}">
	<title>Database Page</title>
</head>
<body>
	<b>Note : To open csv file using excel, read 
		<a href ="https://www.wikihow.com/Open-CSV-Files#Microsoft_Excel_sub">this</a>
	</b>
	<br>
	<button onclick="window.location.href='databaseRegistrant/downloadCsv';">Download CSV</button>
	<br>
	<br>
	<table>
		<tr>
			<th>ID</th>			
			<th>Tiket</th>
			<th>Name</th>
			<th>Email</th>
			<th>NIM</th>
			<th>Phone</th>
			<th>LINE</th>
			<th>Jurusan</th>
			<th>Batch</th>
			<th>Region</th>
			<th>Transport</th>
			<th>Vege</th>
			<th>Baju</th>
			<th>Pembayaran</th>
			<th>TimeStamp</th>
		</tr>
	@foreach($registrants as $registrant)
		<tr>
			<td>{{$registrant->id}}</td>
			<td>{{$registrant->tiket}}</td>
			<td>{{$registrant->name}}}</td>
			<td>{{$registrant->email}}</td>
			<td>{{$registrant->nim}}</td>
			<td>{{$registrant->phone}}</td>
			<td>{{$registrant->line}}</td>
			<td>{{$registrant->jurusan}}</td>
			<td>{{$registrant->batch}}</td>
			<td class="region">{{$registrant->region}}</td>
			<td>{{$registrant->transport}}</td>
			<td>{{$registrant->vege}}</td>
			<td>{{$registrant->baju}}</td>
			<td>{{$registrant->pembayaran}}</td>
			<td>{{$registrant->timeStamp}}</td>
		</tr>
	@endforeach
	</table>
</body>
</html>