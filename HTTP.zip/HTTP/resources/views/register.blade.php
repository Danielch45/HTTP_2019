<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">       
<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<br></br>
<img src="assets/Asset 16.png" alt="Header" style="width:50%"><br></br>
<form action="/register" method="post" style="max-width:1080px;margin:auto">
	{{ csrf_field() }}
    <table id="form">
        <tr>
            <td style="text-align: right">
                <label for="nim" style="font-size:18px;">NIM</label>
            </td>
            <td>
                <div class="input-container">
                    <i class="fa fa-address-card icon" style="font-size:18px"></i>
                    <input class="input-field" type="text" placeholder="NIM" name="nim" id="nim">
                </div>
            </td>
        </tr>
        <tr>
            <td style="text-align: right">
                <label for="nim" style="font-size:18px;">Name</label>
            </td>
            <td>
                <div class="input-container">
                    <i class="fa fa-user icon" style="font-size:18px"></i>
                    <input class="input-field" type="text" placeholder="Name" name="name" id="name">
                </div>
            </td>
        </tr>
        <tr>
            <td style="text-align: right">
                <label for="program" style="font-size:18px;">Program</label>
            </td>
            <td>
                <div class="input-container;" style="font-size:20px;">
                    <select id="program jurusan" name="program">
                        <option value="-">Select Your Program</option>
                        <option value="compSci">Computer Science</option>
                        <option value="masterTrackCompSci">Master Track Computer Science</option>
                        <option value="gameAppTech">Game Application Technology</option>
                        <option value="mobileAppTech">Mobile Application Technology</option>
                        <option value="cyberSec">Cyber Security</option>
                        <option value="itMat">IT MAT</option>
                        <option value="itStat">IT STAT</option>
                        <option value="ppti">PPTI</option>
                    </select>
                </div>
            </td>
        </tr>
        <tr>
            <td style="text-align: right">
                <label for="phoneNumber" style="font-size:18px;">Phone Number</label>
            </td>
            <td >
                <div class="input-container">
                    <i class="fa fa-phone icon" style="font-size:18px"></i>
                    <input class="input-field" type="text" placeholder="08129911726" name="phoneNumber" id="phone">
                </div>            
            </td>
        </tr>
        <tr>
            <td style="text-align: right">
                <label for="lineID" style="font-size:18px;">Line</label>
            </td>
            <td>
                <div class="input-container">
                    <i class="fa fa-address-book icon" style="font-size:18px"></i>
                    <input class="input-field" type="text" placeholder="LINE ID" name="lineID" id="line">
                </div>
            </td>
        </tr>
        <tr>
            <td style="text-align: right">
                <label for="email" style="font-size:18px;">E-mail Address</label>
            </td>
            <td >
                <div class="input-container">
                    <i class="fa fa-envelope icon" style="font-size:18px"></i>
                    <input class="input-field" type="email" placeholder="E-mail Address" name="emailAddress" id="email">
                </div>
            </td>
        </tr>
        <tr>
            <td style="text-align: right">
                <label for="food" style="font-size:18px;">Food</label>
            </td>
            <td>
                <div class="input-container;" style="font-size:18px;">                      
                    <input type="radio" name="food" value="Non-Vege" id="rbNonVege"> Non-Vege
                    <input type="radio" name="food" value="Vege" id="rbVege"> Vege
                </div>
            </td>
        </tr>
        <tr>
            <td style="text-align: right">
                <label for="tshirtSize" style="font-size:18px;">T-Shirt Size</label>
            </td>
            <td >
                <div class="input-container;" style="font-size:10px;">
                    <select id="tshirtSize ddlbaju" name="tshirtSize">
                    	<option value="-">Select your T-Shirt Size</option>
                    	<option value="small">S</option>
                    	<option value="medium">M</option>
                    	<option value="large">L</option>
                    	<option value="extraLarge">XL</option>
                    </select>
                    <br></br>
                </div>
            </td>
        </tr>
        <tr>
            <td style="text-align: right">
                <label for="campusLocation" style="font-size:18px;">Campus Location</label>
            </td>
            <td>
                <div class="input-container;" style="font-size:15px;">
                    <select id="campusLocation" name="campusLocation">
                        <option value="-">Select Campus Location</option>
                        <option value="alsut">Alam Sutera</option>
                        <option value="kemanggisan">Kemanggisan</option>
                        <option value="ppti">PPTI</option>
                    </select>
                </div>
            </td>
        </tr>
        <tr>
            <td style="text-align: right">
                <label for="transport" style="font-size:18px;">Transport</label>
            </td>
            <td >
                <div class="input-container;" style="font-size: 15px;">
                    <select id="transport" name="transport">
                        <option value="personal">Personal Transport</option>
                        <option value="alsut1">Bus 1 (Alsut) : 6.10</option>
                        <option value="alsut2">Bus 2 (Alsut) : 6.20</option>
                        <option value="alsut3">Bus 3 (Alsut) : 6.30</option>
                        <option value="alsut4">Bus 4 (Alsut) : 6.40</option>
                        <option value="kemanggisan1">Bus 1 (Kemanggisan) : 6.20</option>
                        <option value="kemanggisan2">Bus 2 (Kemanggisan) : 6.30</option>
                        <option value="kemanggisan3">Bus 3 (Kemanggisan) : 7.00</option>
                        <option value="kemanggisan4">Bus 4 (Kemanggisan) : 7.10</option>
                        <option value="kemanggisan5">Bus 5 (Kemanggisan) : 7.10</option>
                        <option value="kemanggisan6">Bus 6 (Kemanggisan) : 7.30</option>
                        <option value="ppti1">Bus 1 (PPTI) : 6.20</option>
                    </select>
                    <br></br>
                </div>
            </td>
        </tr>
        <tr>
            <td style="text-align: right">
                <label for="paymentType" style="font-size:18px;">Payment Type</label>
            </td>
            <td>
                <div class="input-container;" style="font-size:18px;">
                    <input type="radio" name="paymentType" value="cash" id="ddlpembayaran"> Cash
                    <input type="radio" name="paymentType" value="transfer" id="ddlpembayaran"> Transfer
                </div>
            </td>
        </tr>
        <tr>
            <td style="text-align: right">
                <label for="ticketNumber" style="font-size:18px;">Ticket Number</label>
            </td>
            <td>
                <div class="input-container">
                    <i class="fa fa-ticket icon" style="font-size:18px"></i>
                    <input class="input-field" type="number" placeholder="Ticket No." name="ticketNumber" id="ticket">
                </div>
            </td>
        </tr>
        <tr>
            <td style="text-align: right">
                <label for="fepBatch" style="font-size:18px;">FEP Batch</label>
            </td>
            <td>
                <div class="input-container">
                    <i class="fa fa-users icon" style="font-size:18px"></i>
                    <input class="input-field" type="number" placeholder="FEP Batch" name="fepBatch" id="batch">
                </div>
            </td>
        </tr>
        <tr>
            <td></td>
            <td >
                <input type="checkbox" name="dataVerif" value="Checked"><label style="font-size:18px">I have entered all the data correctly</label>
            </td>
        </tr>
        
    </table>
    <button type="submit" class="button" style="font-size:20px" id="registerBtn">Submit</button>
</form>


<script src="js/jquery-3.4.1.min.js"></script>
<script src="js/validation.js"></script>
</body>
</html>
