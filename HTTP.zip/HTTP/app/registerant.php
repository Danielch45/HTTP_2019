<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class registerant extends Model
{
    //
    protected $table = 'registerant';
    protected $fillable = [
        'name', 'email', 'nim', 'phone', 'line', 'jurusan', 'batch', 'region', 'transport', 'vege', 'baju'
    ];
}
