<?php 
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Response;
use app\registerant;

class mainController extends Controller
{
	function registerUser(Request $request){
		//Init data to variable
		$name = $request->input('name');//Name
    	$email = $request->input('email');//Email
    	$nim = $request->input('nim');//NIM
    	$phone = $request->input('phone');//Phone Number
        $line = $request->input('line');//ID Line
        $jurusan = $request->input('jurusan');//Jurusan, IT, MIT, GAT, CS, dll
        $batch = $request->input('batch');//batch FEP
        $region = $request->input('region');//region campus, alsut, kemanggisan, ppti
        $transport = $request->input('transport');//Transportasi: Bis, Pribadi
        $vege = $request->input('vege');//tipe makanan(Vege, non Vege)
        $baju = $request->input('baju');//ukuran baju
        $pembayaran = $request->input('pembayaran');//tipe pembayaran (Transfer/Tunai)
        $tiket = $request->input('tiket');//No Tiket, tidak boleh empty !important
        //validation code here..
        //apabila failed dalam validasi, redirect ke /register


        //Insert to database
        DB::table('registerant')->insert([
    		'name' => $name,
    		'email' => $email,
    		'nim' => $nim,
    		'phone' => $phone,
            'line' => $line,
            'jurusan' => $jurusan,
            'batch' => $batch,
            'region' => $region,
            'transport' => $transport,
            'vege' => $vege,
            'baju' => $baju,
            'pembayaran' => $pembayaran,
            'tiket' => $tiket
    	]);
    	return redirect('/success');
	}

}
 ?>