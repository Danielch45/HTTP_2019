function clicked(x)
{
	if(document.getElementById("rightbar").style.opacity == 0)
	{
		showMenu(x);
	}
	else
	{
		closeMenu(x);
	}
}

function showMenu(x)
{
	x.classList.toggle("change");
	var menu = document.getElementById("rightbar");
	menu.style.display = "block";
	setTimeout(function(){
	menu.style.opacity = "1";
	},100);
	setTimeout(function(){
		menu.style.right = "0";
	},100);
}

function closeMenu(x)
{
	x.classList.toggle("change");
	var menu = document.getElementById("rightbar");
	menu.style.opacity = "0";
	setTimeout(function(){
		menu.style.right = "-100%";	
	},100);
	setTimeout(function(){
		menu.style.display = "none";
	},400);

}