$("#registerBtn").click(function(e){
	var error = false;

	// e.preventDefault();//remember to delete this to prevent the form from refreshing

	//name validation done
	var name = document.getElementById('name').value;
	if(name == ''){
		document.getElementById('errName').innerHTML = '*Must be filled';
		error = true;
	}else{
		document.getElementById('errName').innerHTML = ' ';
	}

	//email validation done
	var email = document.getElementById('email').value;
	// var emailValidation = Email.includes('@@' || '@@com');
	if(email == ''){
		document.getElementById('errEmail').innerHTML = '*Must be filled';
		error = true;
	}else{
		document.getElementById('errEmail').innerHTML = ' ';
	}

	// else if(emailValidation == true ){
	// 	document.getElementById('errEmail').innerHTML = '*Your email is invalid';
	// }
	
	// var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	// if(email.value.match(mailformat))
	// {
	// 	document.getElementById('errEmail').innerHTML = '';
	// }
	// else
	// {
	// 	document.getElementById('errEmail').innerHTML = '*Your email is invalid';
	// 	error = true;
	// }


	//nim validation done
	var nim = document.getElementById('nim').value;
	var nimLength = nim.length;
	if(nimLength != 10){
		document.getElementById('errNim').innerHTML = '*Must be exactly 10';
		error = true;
	}else{
		document.getElementById('errNim').innerHTML = ' ';	
	}

	//jurusan validation done
	var jurusan = document.getElementById('jurusan');//jurusan masih salah(untuk validasi dropdown/select box silahkan di cek kembali)
	// var textJurusan = jurusan.selected.value;
	if(jurusan.selectedIndex == 0){
		document.getElementById('errJurusan').innerHTML = '*Must be filled';
		error = true;
	}else{
		document.getElementById('errJurusan').innerHTML = ' ';
	}

	//phone validation  done
	var phone = document.getElementById('phone').value;
	var phoneLength = phone.length;
	if(phoneLength < 10 || phoneLength > 13){
		document.getElementById('errPhone').innerHTML = '*Length Must be between 10-13';
		error = true;
	}
	else{
		document.getElementById('errPhone').innerHTML = ' ';
	}

	//line validation done
	var line = document.getElementById('line').value;
	if(line == ''){
		document.getElementById('errLine').innerHTML = '*Must be filled';
		error = true;
	}
	else{
		document.getElementById('errLine').innerHTML = ' ';
	}

	//batch validation done
	var batch = document.getElementById('batch').value;
	if(batch < 1 || batch > 5 || batch == null){
		document.getElementById('errBatch').innerHTML = '*Must between 1-5';
		error = true;
	}
	else{
		document.getElementById('errBatch').innerHTML = '';
	}

	//region validation done
	var region = document.getElementById('region');
	if (region.selectedIndex == 0)
	{
		document.getElementById('errRegion').innerHTML = '*AS/KG/PPTI';
		error = true;
	} 
	else {
		document.getElementById('errRegion').innerHTML = ' ';
	}

	//transport validation done
	var transport = document.getElementById('transport');
	if(transport.selectedIndex == 0){
		document.getElementById('errTransport').innerHTML = '*Must be filled';
		error = true;
	}
	else{
		document.getElementById('errTransport').innerHTML = ' ';
	}
	
	//vege or non vege validation done
	if(document.getElementById('rbVege').checked == false && document.getElementById('rbNonVege').checked == false){
		document.getElementById('errVege').innerHTML = '*Please select one';
		error = true;
	}else{
		document.getElementById('errVege').innerHTML = '';
	}

	//baju validation done
	var bajuValue = document.getElementById('baju');
	if(bajuValue.selectedIndex == 0){
		document.getElementById('errBaju').innerHTML = '*Must be chosen';
		error = true;
	}
	else{
		document.getElementById('errBaju').innerHTML = ' ';
	}

	// pemabayaran validation done
	if(document.getElementById('ddlTunai').checked == false && document.getElementById('ddlTransfer').checked == false){
		document.getElementById('errPembayaran').innerHTML = '*Please select one';
		error = true;
	}else{
		document.getElementById('errPembayaran').innerHTML = '';
	}

	//tiket validation done
	var ticket = document.getElementById('ticket').value;
	if(ticket == null || ticket == ""){
		document.getElementById('errTicket').innerHTML = '*Must be filled';
		error = true;
	}
	else{
		document.getElementById('errTicket').innerHTML = ' ';
	}

	//pbc validation done
	// var pbcValue = document.getElementById('pbc');
	// if(pbcValue.selectedIndex == 0){
	// 	document.getElementById('errPbc').innerHTML = '*Must be chosen';
	// 	error = true;
	// }
	// else{
	// 	document.getElementById('errPbc').innerHTML = ' ';
	// }

	if(error == true){
        e.preventDefault();
    }
});


// var jurusan = document.getElementById('jurusan');
// idx = jurusan.selectedIndex;

// if(idx == 1){
// 	$(".alsutOpt").css("display", "block");
// 	$(".kgtOpt").css("display", "none");
// 	$("#pbc").attr("enabled");
// }else if(idx == 2){
// 	$(".alsutOpt").css("display", "none");
// 	$(".kgtOpt").css("display", "block");
// 	$("#pbc").attr("enabled");
// }else if(idx == 3){
// 	$(".alsutOpt").css("display", "none");
// 	$(".kgtOpt").css("display", "none");
// 	$("#pbc").attr("disabled");
// }
