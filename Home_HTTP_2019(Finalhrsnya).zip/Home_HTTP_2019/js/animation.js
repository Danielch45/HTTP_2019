window.scrollTo(0,0);

var coverHeight = document.getElementById("coverImage").getBoundingClientRect();

var http = document.getElementById("http");
var httpPos = http.getBoundingClientRect();
http.style.top = '200px';
http.style.opacity = '0';
var checkHttp = false;
// console.log('hehe');

var pbc = document.getElementById("pbc");
var pbcPos = pbc.getBoundingClientRect();
pbc.style.top = '200px';
pbc.style.opacity = '0';
var checkPbc = false;

var register = document.getElementById("register");
var registerPos = register.getBoundingClientRect();
register.style.top = '200px';
register.style.opacity = '0';
var checkRegis = false;

var himtiKit = document.getElementById("himtiKit");
var himtiKitPos = himtiKit.getBoundingClientRect();
himtiKit.style.top = '200px';
himtiKit.style.opacity = '0';
var checkHimtikit = false;

var faq = document.getElementById("faq");
var faqPos = faq.getBoundingClientRect();
faq.style.top = '200px';
faq.style.opacity = '0';
var checkFaq = false;

var footer = document.getElementById("footer");
var footerPos = footer.getBoundingClientRect();
footer.style.top = '200px';
footer.style.opacity = '0';
document.getElementById("credits").style.opacity = "0";
document.getElementById("credits").style.top = "200px";
var checkFooter = false;

var containerPos = document.getElementById("container").getBoundingClientRect();

var navBtn = document.getElementsByTagName('a');

window.onscroll = function()
{
	var currYPos = window.pageYOffset;
	show_bg(currYPos);
	// alert(currYPos + "=>" + httpPos.top);
	/*Scroll Fade-in*/ 
	// var pos =  (httpPos.top - (coverHeight.height*65/100));
		// console.log("pos : " + pos + " Ypos : " + currYPos + " Status : " + checkHttp);
	if(currYPos >= (httpPos.top - (coverHeight.height*65/100)))
	{
		/*Will run if user has scroll up to 100%-65% of coverHeight*/
		whiteNavBtn();
		document.getElementById('toHttp').style.color = "#19a8b8";
		if(checkHttp == false)
		{
			// console.log("eheh");			
			http.style.opacity = '1';
			setTimeout(function(){http.style.top = '0px';},50);
			checkHttp = true;
		}
	}
	if(currYPos >= (pbcPos.top - containerPos.top -(httpPos.height*55/100)))
	{
		whiteNavBtn();
		document.getElementById('toPbc').style.color = "#19a8b8";
		if(checkPbc == false)
		{
			pbc.style.opacity = '1';
			setTimeout(function(){pbc.style.top = '0px';},50);
			checkPbc = true;
		}

	}
	if(currYPos >= (registerPos.top- containerPos.top-(pbcPos.height*55/100)))
	{
		whiteNavBtn();
		document.getElementById('toRegis').style.color = "#19a8b8";
		if(checkRegis == false)
		{
			register.style.opacity = '1';
			setTimeout(function(){register.style.top = '0px';},50);
			checkRegis = true;
		}
	}
	if(currYPos >= (himtiKitPos.top- containerPos.top-(registerPos.height*30/100)))
	{
		whiteNavBtn();
		document.getElementById('toHimtiKit').style.color = "#19a8b8";	
		if(checkHimtikit == false)
		{
			himtiKit.style.opacity = '1';
			setTimeout(function(){himtiKit.style.top = '0px';},50);
			checkHimtikit = true;
		}
	}
	if(currYPos >= (faqPos.top- containerPos.top-(himtiKitPos.height*55/100)))
	{
		whiteNavBtn();
		document.getElementById('toFaq').style.color = "#19a8b8";
		if(checkFaq == false)
		{
			faq.style.opacity = '1';
			setTimeout(function(){faq.style.top = '0px';},50);
			checkFaq = true;
		}
	}
	if(currYPos >= (footerPos.top- containerPos.top-(faqPos.height*55/100)))
	{
		if(checkFooter == false )
		{
			document.getElementById("credits").style.opacity = "1";			
			footer.style.opacity = '1';
			setTimeout(function(){
				footer.style.top = '0px';
				document.getElementById("credits").style.top = "0px";
			},50);
			checkFooter = true;
		}
	}
	// console.log(currYPos + "=>" + httpPos.top + containerPos.top + (httpPos.height*45/100));
}

function show_bg(currYPos)
{
	if(currYPos > 0)
	{
		document.getElementById("navbar").style.padding = "0";
		document.getElementById("header").style.background = "rgba(0,0,0,.65)";
		document.getElementById("logo-http").style.height = "2em";
		document.getElementById("rightbar").style.fontSize = "1.3em";
	}
	else
	{
		document.getElementById("navbar").style.padding = "1% 0%";
		document.getElementById("header").style.background = "none";	
		document.getElementById("logo-http").style.height = "2.3em";
		document.getElementById("rightbar").style.fontSize = "1.6em";
		whiteNavBtn();
		document.getElementById('toHome').style.color = "#19a8b8";
	}
	return;
}

function whiteNavBtn()
{
	for(i = 0 ; i < navBtn.length ; i++)
	{
		navBtn[i].style.color = "white";
	}
}

function changeColor(x)
{
	x.style.color = "#19a8b8";
}

function turnWhite(x)
{
	x.style.color = "white";
}

var $root = $('html, body');

$('a[href^="#"]').click(function () {
    $root.animate({
        scrollTop: $( $.attr(this, 'href') ).offset().top-150
    }, 500);

    return false;
});