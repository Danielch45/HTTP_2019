<?php 
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Response;
use app\registerant;

class mainController extends Controller
{
	function registerUser(Request $request){
		//Init data to variable
		$name = $request->input('name');//Name
    	$email = $request->input('email');//Email
    	$nim = $request->input('nim');//NIM
    	$phone = $request->input('phone');//Phone Number
        $line = $request->input('line');//ID Line
        $jurusan = $request->input('jurusan');//Jurusan, IT, MIT, GAT, CS, dll
        $batch = $request->input('batch');//batch FEP
        $region = $request->input('region');//region campus, alsut, kemanggisan, ppti
        $transport = $request->input('transport');//Transportasi: Bis, Pribadi
        $vege = $request->input('vege');//tipe makanan(Vege, non Vege)
        $baju = $request->input('baju');//ukuran baju
        $pembayaran = $request->input('pembayaran');//tipe pembayaran (Transfer/Tunai)
        $tiket = $request->input('tiket');//No Tiket, tidak boleh empty !important
        //validation code here..
        //apabila failed dalam validasi, redirect ke /register


        //Insert to database
        DB::table('registerant')->insert([
    		'name' => $name,
    		'email' => $email,
    		'nim' => $nim,
    		'phone' => $phone,
            'line' => $line,
            'jurusan' => $jurusan,
            'batch' => $batch,
            'region' => $region,
            'transport' => $transport,
            'vege' => $vege,
            'baju' => $baju,
            'pembayaran' => $pembayaran,
            'tiket' => $tiket
    	]);

        $curr_nim_name = $nim . " " . $name;
        return view('success');
    	// return view('success')->with('curr_nim_name', $curr_nim_name);
	}

    function viewRegistrant()
    {
        $registrants = DB::table('registerant')->get();

        return view('databaseRegistrant')->with('registrants',$registrants);
    }

    function csvExport()
    {
        $registrants = DB::table('registerant')->get();
        $fileName = date("Y-m-d H:i:s") . "Registrant_Data.csv";
        $path ="php://memory";
        $handle = fopen($path, "w");

        $tableHead = array('id','tiket','name','email', 'nim','phone','line','jurusan','batch','region','transport','vege','baju','pembayaran','timeStamp');

        header('Content-Type: text/csv');
        header("Content-Disposition: attachment; filename=".$fileName.";");
        
        // For excel
        // fputcsv($handle ,array_values($tableHead),';',' ');

        fputcsv($handle ,array_values($tableHead));

        foreach ($registrants as $registrant)
        {
            $data = array(
                $registrant->id,
                $registrant->tiket,
                $registrant->name,
                $registrant->email,
                $registrant->nim,
                $registrant->phone,
                $registrant->line,
                $registrant->jurusan,
                $registrant->batch,
                $registrant->region,
                $registrant->transport,
                $registrant->vege,
                $registrant->baju,
                $registrant->pembayaran,
                $registrant->timeStamp,
            );
            fputcsv($handle, $data);
        }
        rewind($handle);
        // $stream = stream_get_contents($handle);
        // echo $stream;   
        fpassthru($handle);
        fclose($handle);
        return;
    }
}
?>