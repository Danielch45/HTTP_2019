<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="{{asset('css/success.css')}}">
	<title>SUCCESS</title>
</head>
<body style="background-image: url('{{asset('img/Background.png')}}');">
	<div id="success-detail">
		<img src="{{asset('img/Asset1.png')}}" id="background">
		<div id="detail">
			<b>Test</b>
			<!-- {{$curr_nim_name}} -->
		</div>
	</div>
</body>
</html>