<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/database.css')); ?>">
	<title>Database Page</title>
</head>
<body>
	<b>Note : To open csv file using excel, read 
		<a href ="https://www.wikihow.com/Open-CSV-Files#Microsoft_Excel_sub">this</a>
	</b>
	<br>
	<button onclick="window.location.href='databaseRegistrant/downloadCsv';">Download CSV</button>
	<br>
	<br>
	<table>
		<tr>
			<th>ID</th>			
			<th>Tiket</th>
			<th>Name</th>
			<th>Email</th>
			<th>NIM</th>
			<th>Phone</th>
			<th>LINE</th>
			<th>Jurusan</th>
			<th>Batch</th>
			<th>Region</th>
			<th>Transport</th>
			<th>Vege</th>
			<th>Baju</th>
			<th>Pembayaran</th>
			<th>TimeStamp</th>
		</tr>
	<?php $__currentLoopData = $registrants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registrant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($registrant->id); ?></td>
			<td><?php echo e($registrant->tiket); ?></td>
			<td><?php echo e($registrant->name); ?>}</td>
			<td><?php echo e($registrant->email); ?></td>
			<td><?php echo e($registrant->nim); ?></td>
			<td><?php echo e($registrant->phone); ?></td>
			<td><?php echo e($registrant->line); ?></td>
			<td><?php echo e($registrant->jurusan); ?></td>
			<td><?php echo e($registrant->batch); ?></td>
			<td class="region"><?php echo e($registrant->region); ?></td>
			<td><?php echo e($registrant->transport); ?></td>
			<td><?php echo e($registrant->vege); ?></td>
			<td><?php echo e($registrant->baju); ?></td>
			<td><?php echo e($registrant->pembayaran); ?></td>
			<td><?php echo e($registrant->timeStamp); ?></td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
</body>
</html>